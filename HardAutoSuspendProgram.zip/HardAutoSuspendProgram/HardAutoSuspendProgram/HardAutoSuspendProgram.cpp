// HardAutoSuspendProgram.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <Windows.h>
#include <string>

typedef NTSTATUS (NTAPI* NtSuspendThreadObj)(HANDLE pid);

int main()
{
    int userPid = 0;
    std::string userState = "";
    std::cout << "PID: ";
    std::cin >> userPid;
    std::cout << "[S] Suspend, [R] Resume, [CS] Continuous Suspend: ";
    std::cin >> userState;
    for (char& c : userState) {
        c = std::tolower(c);
    }
    if (userState == "s") {
        HMODULE ntdllModule = GetModuleHandleA("ntdll.dll");
        if (ntdllModule) {
            std::cout << "Found Module (ntdll.dll)\n";
            NtSuspendThreadObj NtSuspendProcess = (NtSuspendThreadObj)GetProcAddress(ntdllModule, "NtSuspendProcess");
            HANDLE targetProcess = OpenProcess(PROCESS_SUSPEND_RESUME, false, userPid);
            std::cout << "Suspending PID " << userPid << "...\n";
            if (targetProcess) {
                NtSuspendProcess(targetProcess);
            }
            else {
                std::cout << "Process Not Found";
            }
        }
        else {
            std::cout << "ntdll.dll was not found? (Error Or Your Operating System Will Combust Into Flames)";
        }
    }
    else if (userState == "r") {
        HMODULE ntdllModule = GetModuleHandleA("ntdll.dll");
        if (ntdllModule) {
            std::cout << "Found Module (ntdll.dll)\n";
            NtSuspendThreadObj NtResumeProcess = (NtSuspendThreadObj)GetProcAddress(ntdllModule, "NtResumeProcess");
            HANDLE targetProcess = OpenProcess(PROCESS_SUSPEND_RESUME, false, userPid);
            std::cout << "Resuming PID " << userPid << "...\n";
            if (targetProcess) {
                NtResumeProcess(targetProcess);
            }
            else {
                std::cout << "Process Not Found";
            }
            
        }
        else {
            std::cout << "ntdll.dll was not found? (Error Or Your Operating System Will Combust Into Flames)";
        }
    }
    else if (userState == "cs") {
        DWORD loopSleepTime = 0;
        system("cls");
        std::cout << "Delay: ";
        std::cin >> loopSleepTime;
        HMODULE ntdllModule = GetModuleHandleA("ntdll.dll");
        if (ntdllModule) {
            std::cout << "Found Module (ntdll.dll)\n";
            NtSuspendThreadObj NtSuspendProcess = (NtSuspendThreadObj)GetProcAddress(ntdllModule, "NtSuspendProcess");
            HANDLE targetProcess = OpenProcess(PROCESS_SUSPEND_RESUME, false, userPid);
            std::cout << "Suspending PID " << userPid << "...\n";
            while (true) {
                if (targetProcess) {
                    NtSuspendProcess(targetProcess);
                }
                else {
                    std::cout << "Process Not Found";
                    break;
                }
                Sleep(loopSleepTime);
            }
        }
        else {
            std::cout << "ntdll.dll was not found? (Error Or Your Operating System Will Combust Into Flames)";
        }
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
